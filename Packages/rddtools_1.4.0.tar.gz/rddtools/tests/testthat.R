library(testthat)
library(rddtools)

test_check("rddtools") 
